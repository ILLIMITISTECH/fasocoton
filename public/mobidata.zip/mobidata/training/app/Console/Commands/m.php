<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Notification;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\Notifications\BienvenueACollaboratis;
use App\Agent;
use App\Service;
use App\Direction;
use App\User;
use App\Role;
use Auth;
use DB;
use Mail;
use App\Mail\SendMail;
use Session;

class AgentController extends Controller
{
    use AuthenticatesUsers;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    } 
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        //$agents = Agent::all();
        /*$agents = DB::table('agents')
        ->select('agents.prenom', 'agents.nom', 'agents.photo', 'agents.service_id', 'agents.date_naiss', 'agents.id',
        'services.nom_service','services.direction')
        ->join('services', 'services.id', 'agents.service_id')
        ->join('directions', 'directions.id', 'agents.direction_id')
        ->get();*/
        $directions = Direction::all();
         $agents = DB::table('agents')
          ->join('directions', 'directions.id', 'agents.direction_id')
          ->select(
                  'agents.prenom', 'agents.nom', 'agents.photo', 'agents.direction_id', 'agents.date_naiss', 'agents.id',
                  'directions.nom_direction','directions.id as ID')
                  ->get();
        return view('cameg/agent.lister', compact('agents','directions'));
    }
    
     public function filter_ag(Request $request){
        $search_ag = $request->get('search_ag');
        $directions = Direction::all();
        
           $agents = DB::table('agents')
          //->join('agents', 'agents.direction_id', 'directions.id')
          ->join('directions', 'directions.id', 'agents.direction_id')
          ->select(
                  'agents.prenom', 'agents.nom', 'agents.photo', 'agents.direction_id', 'agents.date_naiss', 'agents.id',
                  'directions.nom_direction','directions.id as ID')
                  ->where('directions.nom_direction', 'like', '%'.$search_ag.'%')
                  ->get();

       return view('cameg/agent.lister', compact('agents','directions'));
      }    
     


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $services = Service::all();
        $directions = Direction::all();
        $roles = Role::all();
        $agents = Agent::all();
        return view('cameg/agent.ajouter',compact('services', 'roles', 'agents','directions'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        //request()->validate([
            //'photo.*' => 'mimes:doc,pdf,docx,zip,png,jpeg,odt,jpg,svc,csv,mpeg,ogg,mp4,webm,3gp,mov,flv,avi,wmv,ts',
            //'nom' => 'required|string|max:255',
            //'prenom' => 'required|string|max:255',
            //'email' => 'required|string|max:255',
            

    //]);
    
        

                        
                       
                    //}
                $message = "Agent ajouté avec succès !";

                $user = new User;
                $user->prenom = $request->get('prenom');
                $user->nom = $request->get('nom');
                $user->email = $request->get('email');
                $user->nom_role = $request->get('nom_role');
                $user->role_id = $request->get('role_id');
                $user->password = Hash::make($request->get('password'));
                $user->notify(new BienvenueACollaboratis());

                if($user->save()){
                    error_log('la création a réussi');

                $agent = new Agent;
                $agent->prenom = $request->get('prenom'); 
                $agent->nom = $request->get('nom'); 
                $agent->email = $request->get('email'); 
                $agent->tel = $request->get('tel'); 
                $agent->whatshap = $request->get('whatshap'); 
                $agent->fonction = $request->get('fonction'); 
                $agent->date_naiss = $request->get('date_naiss'); 
                $agent->niveau_hieracie = $request->get('niveau_hieracie'); 
                $agent->superieur_id = $request->get('superieur_id'); 
                $agent->service_id = $request->get('service_id');
                $agent->direction_id = $request->get('direction_id');
                $agent->user_id = $request->get('user_id');  
                $agent->user_id = $user->id;
                    //$agents->save();
                    if($agent->save())
                    {
                        Auth::login($user);
                        //$user->notify(new BienvenueACollaboratis());
                        
                        $send = DB::table('users')->select('prenom')->where('id', '=', Auth::user()->id)->first();
                        
                            $prenom = $send->prenom;
                           
                           $to = Auth::user()->email;
                           $subject = "Bienvenue sur Collaboratis";
                           $body = "<!doctype html><html xmlns='http://www.w3.org/1999/xhtml' xmlns:v='urn:schemas-microsoft-com:vml' xmlns:o='urn:schemas-microsoft-com:office:office'><head><title>Collaboratis</title><!--[if !mso]><!-- --><meta http-equiv='X-UA-Compatible' content='IE=edge'><!--<![endif]--><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><style type='text/css'>#outlook a { padding:0; }
                                  body { margin:0;padding:0;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%; }
                                  table, td { border-collapse:collapse;mso-table-lspace:0pt;mso-table-rspace:0pt; }
                                  img { border:0;height:auto;line-height:100%; outline:none;text-decoration:none;-ms-interpolation-mode:bicubic; }
                                  p { display:block;margin:13px 0; }</style><!--[if mso]>
                                <xml>
                                <o:OfficeDocumentSettings>
                                  <o:AllowPNG/>
                                  <o:PixelsPerInch>96</o:PixelsPerInch>
                                </o:OfficeDocumentSettings>
                                </xml>  
                                <![endif]--><!--[if lte mso 11]>
                                <style type='text/css'>
                                  .mj-outlook-group-fix { width:100% !important; }
                                </style>
                                <![endif]--><!--[if !mso]><!--><link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'><style type='text/css'>@import url(https://fonts.googleapis.com/css?family=Montserrat);</style><!--<![endif]--><style type='text/css'>@media only screen and (min-width:480px) {
                                .mj-column-per-67 { width:67% !important; max-width: 67%; }
                                .mj-column-per-33 { width:33% !important; max-width: 33%; }
                                .mj-column-per-100 { width:100% !important; max-width: 100%; }
                                .mj-column-per-25 { width:25% !important; max-width: 25%; }
                                .mj-column-per-75 { width:75% !important; max-width: 75%; }
                                    }</style><style type='text/css'>[owa] .mj-column-per-67 { width:67% !important; max-width: 67%; }
                                [owa] .mj-column-per-33 { width:33% !important; max-width: 33%; }
                                [owa] .mj-column-per-100 { width:100% !important; max-width: 100%; }
                                [owa] .mj-column-per-25 { width:25% !important; max-width: 25%; }
                                [owa] .mj-column-per-75 { width:75% !important; max-width: 75%; }</style><style type='text/css'>@media only screen and (max-width:480px) {
                              table.mj-full-width-mobile { width: 100% !important; }
                              td.mj-full-width-mobile { width: auto !important; }
                            }</style></head><body style='background-color:#F4F4F4;'><div style='background-color:#F4F4F4;'><!--[if mso | IE]><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='width:100%;'><tbody><tr><td style='direction:ltr;font-size:0px;padding:20px 0px 20px 0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:402px;' ><![endif]--><div class='mj-column-per-67 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='left' style='font-size:0px;padding:0px 0px 0px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:13px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;'><p style='margin: 10px 0;'></p></div></td></tr></table></div><!--[if mso | IE]></td><td class='' style='vertical-align:top;width:198px;' ><![endif]--><div class='mj-column-per-33 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='left' style='font-size:0px;padding:0px 25px 0px 0px;padding-top:0px;padding-bottom:0px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:13px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;'><p style='text-align: right; margin: 10px 0; margin-top: 10px; margin-bottom: 10px;'><span style='font-size:13px;text-align:right;color:#55575d;font-family:Arial;line-height:22px;'><a href='[[PERMALINK]]' style='color:inherit;text-decoration:none;' target='_blank'>View online version</a></span></p></div></td></tr></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='background:#4b78a8;background-color:#4b78a8;margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#4b78a8;background-color:#4b78a8;width:100%;'><tbody><tr><td style='border:0px solid #ffffff;direction:ltr;font-size:0px;padding:20px 0px 20px 0px;padding-left:0px;padding-right:0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:600px;' ><![endif]--><div class='mj-column-per-100 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='left' style='background:#4b78a8;font-size:0px;padding:0px 25px 0px 25px;padding-top:0px;padding-right:25px;padding-bottom:0px;padding-left:25px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:25px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;'><p class='text-build-content' style='text-align: center; margin: 10px 0; margin-top: 10px; margin-bottom: 10px;' data-testid='mh3RJ-QHU'><span style='color:#ffffff;font-family:Montserrat;font-size:25px;'><b>Bienvenue sur Collaboratis !</b></span></p></div></td></tr></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#ffffff;background-color:#ffffff;width:100%;'><tbody><tr><td style='direction:ltr;font-size:0px;padding:20px 0px 20px 0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:600px;' ><![endif]--><div class='mj-column-per-100 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='left' style='font-size:0px;padding:0px 25px 0px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:16px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;'><p class='text-build-content' data-testid='R84VCxqdu-hsz' style='margin: 10px 0; margin-top: 10px;'>
                            <span style='color:#000000;font-family:Montserrat;font-size:16px;line-height:22px;'>Hello <strong> $prenom </strong></span></p><p class='text-build-content' data-testid='R84VCxqdu-hsz' style='margin: 10px 0;'><span style='color:#000000;font-family:Montserrat;font-size:16px;line-height:22px;'>Merci d'avoir choisi Collaboratis.</span></p><p class='text-build-content' data-testid='R84VCxqdu-hsz' style='margin: 10px 0; margin-bottom: 10px;'><span style='color:#000000;font-family:Montserrat;font-size:16px;line-height:22px;'>Votre compte viens d'être crée par l'administrateur, vous pouvez dès maintenant vous connecter.</span></p></div></td></tr></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#ffffff;background-color:#ffffff;width:100%;'><tbody><tr><td style='border:0px solid #ffffff;direction:ltr;font-size:0px;padding:0px 0px 0px 0px;padding-bottom:0px;padding-left:0px;padding-right:0px;padding-top:0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:600px;' ><![endif]--><div class='mj-column-per-100 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='center' vertical-align='middle' style='font-size:0px;padding:10px 25px 10px 25px;padding-right:25px;padding-left:25px;word-break:break-word;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='border-collapse:separate;line-height:100%;'><tr><td align='center' bgcolor='#4b78a8' role='presentation' style='border:0px solid #ffffff;border-radius:3px;cursor:auto;mso-padding-alt:10px 25px 10px 25px;background:#4b78a8;' valign='middle'><p style='display:inline-block;background:#4b78a8;color:#ffffff;font-family:Arial, sans-serif;font-size:18px;font-weight:normal;line-height:120%;margin:0;text-decoration:none;text-transform:none;padding:10px 25px 10px 25px;mso-padding-alt:0px;border-radius:3px;'><span style='font-family:Montserrat;font-size:16px;'><b><a href='https://cameg.collaboratis.com/connexion' style='text-decoration:none; color:white;'>C'est parti </a> !</b></span></p></td></tr></table></td></tr></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#ffffff;background-color:#ffffff;width:100%;'><tbody><tr><td style='border:0px solid #ffffff;direction:ltr;font-size:0px;padding:20px 0px 20px 0px;padding-left:0px;padding-right:0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:600px;' ><![endif]--><div class='mj-column-per-100 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='left' style='font-size:0px;padding:10px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:18px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;'><p class='text-build-content' style='text-align: center; margin: 10px 0; margin-top: 10px; margin-bottom: 10px;' data-testid='N9aYWMawZ'><span style='font-family:Montserrat;font-size:18px;'><b>Collaboratis c'est :&nbsp;</b></span></p></div></td></tr></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#ffffff;background-color:#ffffff;width:100%;'><tbody><tr><td style='border:0px solid #ffffff;direction:ltr;font-size:0px;padding:0px 0px 0px 0px;padding-bottom:0px;padding-left:0px;padding-right:0px;padding-top:0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:150px;' ><![endif]--><div class='mj-column-per-25 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='center' style='font-size:0px;padding:10px 0px 10px 50px;padding-right:0px;padding-left:50px;word-break:break-word;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='border-collapse:collapse;border-spacing:0px;'><tbody><tr><td style='width:24px;'><img alt='' height='auto' src='https://xtxky.mjt.lu/tplimg/xtxky/b/0x2ps/g3gj6.png' style='border:none;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;' width='24'></td></tr></tbody></table></td></tr></table></div><!--[if mso | IE]></td><td class='' style='vertical-align:top;width:450px;' ><![endif]--><div class='mj-column-per-75 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='left' style='font-size:0px;padding:5px 25px 0px 0px;padding-top:5px;padding-right:25px;padding-bottom:0px;padding-left:0px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:15px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;'><p class='text-build-content' data-testid='cx1NR-eGj' style='margin: 10px 0; margin-top: 10px; margin-bottom: 10px;'><span style='font-family:Montserrat;font-size:15px;'>Mises à jour et suivi des indicateurs de performance</span></p></div></td></tr></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#ffffff;background-color:#ffffff;width:100%;'><tbody><tr><td style='border:0px solid #ffffff;direction:ltr;font-size:0px;padding:0px 0px 0px 0px;padding-bottom:0px;padding-left:0px;padding-right:0px;padding-top:0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:150px;' ><![endif]--><div class='mj-column-per-25 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='center' style='font-size:0px;padding:10px 0px 10px 50px;padding-right:0px;padding-left:50px;word-break:break-word;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='border-collapse:collapse;border-spacing:0px;'><tbody><tr><td style='width:24px;'><img alt='' height='auto' src='https://xtxky.mjt.lu/tplimg/xtxky/b/0x2ps/g3gk7.png' style='border:none;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;' width='24'></td></tr></tbody></table></td></tr></table></div><!--[if mso | IE]></td><td class='' style='vertical-align:top;width:450px;' ><![endif]--><div class='mj-column-per-75 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='left' style='font-size:0px;padding:5px 25px 0px 5px;padding-top:5px;padding-right:25px;padding-bottom:0px;padding-left:5px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:15px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;'><p class='text-build-content' data-testid='C1Zd1b70iG' style='margin: 10px 0; margin-top: 10px; margin-bottom: 10px;'><span style='font-family:Montserrat;font-size:15px;'>Vue sur la performance individuelle et collective</span></p></div></td></tr></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#ffffff;background-color:#ffffff;width:100%;'><tbody><tr><td style='border:0px solid #ffffff;direction:ltr;font-size:0px;padding:0px 0px 0px 0px;padding-bottom:0px;padding-left:0px;padding-right:0px;padding-top:0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:150px;' ><![endif]--><div class='mj-column-per-25 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='center' style='font-size:0px;padding:10px 0px 10px 50px;padding-right:0px;padding-left:50px;word-break:break-word;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='border-collapse:collapse;border-spacing:0px;'><tbody><tr><td style='width:24px;'><img alt='' height='auto' src='https://xtxky.mjt.lu/tplimg/xtxky/b/0x2ps/g3gkr.png' style='border:none;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;' width='24'></td></tr></tbody></table></td></tr></table></div><!--[if mso | IE]></td><td class='' style='vertical-align:top;width:450px;' ><![endif]--><div class='mj-column-per-75 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='left' style='font-size:0px;padding:5px 25px 0px 5px;padding-top:5px;padding-right:25px;padding-bottom:0px;padding-left:5px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:15px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;'><p class='text-build-content' data-testid='6r9esoh8lC' style='margin: 10px 0; margin-top: 10px; margin-bottom: 10px;'><span style='font-family:Montserrat;font-size:15px;'>Rappels et alarmes</span></p></div></td></tr></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='background:#4b78a8;background-color:#4b78a8;margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#4b78a8;background-color:#4b78a8;width:100%;'><tbody><tr><td style='border:0px solid #ffffff;direction:ltr;font-size:0px;padding:20px 0px 20px 0px;padding-left:0px;padding-right:0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:600px;' ><![endif]--><div class='mj-column-per-100 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top;' width='100%'><tr><td align='left' style='background:#4b78a8;font-size:0px;padding:10px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:15px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;'><p class='text-build-content' style='text-align: center; margin: 10px 0; margin-top: 10px;' data-testid='JPnv5a-JbzSEF'><span style='color:#ffffff;font-family:Montserrat;font-size:15px;'><b>Collaboratis</b></span></p><p class='text-build-content' style='text-align: center; margin: 10px 0; margin-bottom: 10px;' data-testid='JPnv5a-JbzSEF'><span style='color:#ffffff;font-family:Montserrat;font-size:15px;line-height:22px;'><b>La plateforme qui facilite de suivi de la performance collective des organisations</b></span></p></div></td></tr></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><table align='center' border='0' cellpadding='0' cellspacing='0' class='' style='width:600px;' width='600' ><tr><td style='line-height:0px;font-size:0px;mso-line-height-rule:exactly;'><![endif]--><div style='margin:0px auto;max-width:600px;'><table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='width:100%;'><tbody><tr><td style='direction:ltr;font-size:0px;padding:20px 0px 20px 0px;text-align:center;'><!--[if mso | IE]><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td class='' style='vertical-align:top;width:600px;' ><![endif]--><div class='mj-column-per-100 mj-outlook-group-fix' style='font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' width='100%'><tbody><tr><td style='vertical-align:top;padding:0;'><table border='0' cellpadding='0' cellspacing='0' role='presentation' width='100%'><tr><td align='center' style='font-size:0px;padding:10px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:11px;letter-spacing:normal;line-height:22px;text-align:center;color:#000000;'><p style='margin: 10px 0;'>e-mail transmis a collaboratis@gmail.com, <a href='collaboratis@gmail.com' style='color:inherit;text-decoration:none;' target='_blank'></a>.</p></div></td></tr><tr><td align='center' style='font-size:0px;padding:10px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;'><div style='font-family:Arial, sans-serif;font-size:11px;letter-spacing:normal;line-height:22px;text-align:center;color:#000000;'><p class='text-build-content' style='text-align: center; margin: 10px 0; margin-top: 10px; margin-bottom: 10px;' data-testid='F4I1rXm1Jzt'>SN</p></div></td></tr></table></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><![endif]--></td></tr></tbody></table></div><!--[if mso | IE]></td></tr></table><![endif]--></div></body></html>";
                                
                           $headers = "From: notification.collaboratis@gmail.com" . "\r\n" 
                                            ."CC: fallougueye197@gmail.com /n"
                                            ."Reply-To:notification.collaboratis@gmail.com\n"
                                            ."Content-Type:text/html;charset=\"utf-8\"";
                                            
                           mail($to,$subject,$body,$headers);
                           
                      
                        
                        
                            echo '<br><br><br> <span class="alert alert-success" role="alert" style ="margin-top : 100px; margin-left : 150px; width : 350px;"> Les Mails ont été envoyés avec succès </span>';
                       
                        return redirect('/agents')->with(['message' => $message]);

                    }
                    else
                    {
                        flash('user not saved')->error();

                    }

                }    
                 return redirect('/agents')->with(['message' => $message]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //  
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $agent = Agent::find($id);
        $services = Service::all();
        $directions = Direction::all();
        $roles = Role::all();
        $agents = Agent::all();
        return view('cameg/agent.edite', compact('roles','services', 'agent', 'agents','directions'));

    }
  
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
           request()->validate([
                    //'photo.*' => 'mimes:doc,pdf,docx,zip,png,jpeg,odt,jpg,svc,csv,mpeg,ogg,mp4,webm,3gp,mov,flv,avi,wmv,ts',
                   
        
            ]);
            $image = $request->file('photo');
            if($image){
            $imageName = $image->getClientOriginalName();
            $image->move(public_path().'/images/', $imageName);
                } 
                $message = "Agent modifié avec succès !";

                /* $user = User::find($id);
                $user->prenom = $request->get('prenom');
                $user->nom = $request->get('nom');
                $user->email = $request->get('email');
                $user->photo = $imageNameP;
                $user->nom_role = $request->get('nom_role');
                $user->role_id = $request->get('role_id');
                $user->password = Hash::make($request->get('password'));
                $user->notify(new RegisterNotify());

                if($user->update()){
                    error_log('la création a réussi'); */

                $agent = Agent::find($id);
                $agent->prenom = $request->get('prenom'); 
                $agent->nom = $request->get('nom'); 
                //$agent->photo =  $imageName; 
                $agent->email = $request->get('email'); 
                $agent->tel = $request->get('tel'); 
                $agent->whatshap = $request->get('whatshap'); 
                $agent->fonction = $request->get('fonction'); 
                $agent->date_naiss = $request->get('date_naiss'); 
                $agent->niveau_hieracie = $request->get('niveau_hieracie'); 
                $agent->superieur_id = $request->get('superieur_id'); 
                $agent->service_id = $request->get('service_id');
                $agent->direction_id = $request->get('direction_id');
                $agent->user_id = $request->get('user_id');  
                $agent->update();
                   /*  //$agents->save();
                    if($agent->update())
                    {
                        Auth::login($user);
                        return back()->with(['message' => $message]);

                    }
                    else
                    {
                        flash('user not saved')->error();

                    }

                }     */

        return redirect('/agents')->with(['message' => $message]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $agent = Agent::find($id);
        $agent->delete();
        
        //$user = User::where('id',$agent->id)->find($id);
        //$user->delete();

        return back();
    }
}
