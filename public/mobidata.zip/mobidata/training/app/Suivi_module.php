<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Suivi_module extends Model
{
    //
}
