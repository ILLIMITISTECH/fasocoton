<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="#"><img class="main-logo" src="{{asset('images/illimitis/collobo.jpeg')}}" style="width:150px;" alt="" /></a>
                <strong><a href="#"><img src="{{asset('images/illimitis/collobo.jpeg')}}" style="width:150px;" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a class="arrow" href="/admin/dashboard/directeur">
								   
								   <a title="Dashboard v.1" href="/admin/dashboard/directeur">Accueil</a>
								</a>
                             <!--<ul class="submenu-angle" aria-expanded="true">
                                <li><a title="Dashboard v.1" href="/admin/dashboard/directeur"><span class="mini-sub-pro">Accueil</span></a></li>
                                <li><a title="Dashboard v.2" href="#"><span class="mini-sub-pro">Dashboard v.2</span></a></li>
                                <li><a title="Dashboard v.3" href="#"><span class="mini-sub-pro">Dashboard v.3</span></a></li>
                                <li><a title="Analytics" href="#"><span class="mini-sub-pro">Analytics</span></a></li>
                                <li><a title="Widgets" href="#"><span class="mini-sub-pro">Widgets</span></a></li> 
                            </ul>  -->
                        </li>
                        
                         <li>
                            <a class="has-arrow" href="/user_annonce" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Annonces</span></a>
                            <ul class="submenu-angle" aria-expanded="false"> 
                            <li><a title="All Students" href="/ajout_annonce"><span class="mini-sub-pro">Passer une Annonces</span></a></li>
                            <li><a title="All Students" href="/user_annonce"><span class="mini-sub-pro">Toutes les Annonces</span></a></li>
                               <!--  <li><a title="All Students" href="/agents"><span class="mini-sub-pro">Tous les Agents</span></a></li>
                                <li><a title="Add Students" href="/agents/create"><span class="mini-sub-pro">Ajouter des Agent</span></a></li> -->
                               <!--  <li><a title="Edit Students" href="edit-student.html"><span class="mini-sub-pro">Edit Student</span></a></li>
                                <li><a title="Students Profile" href="student-profile.html"><span class="mini-sub-pro">Student Profile</span></a></li> -->
                             </ul>
                        </li>
                        
                         <li>
                            <a class="arrow" href="/user_reunion_dg" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Reunions</span></a>
                            <!--<ul class="submenu-angle" aria-expanded="false"> 
                            <li><a title="All Students" href="/user_reunion_dg"><span class="mini-sub-pro">Reunions</span></a></li>-->
                               <!--  <li><a title="All Students" href="/agents"><span class="mini-sub-pro">Tous les Agents</span></a></li>
                                <li><a title="Add Students" href="/agents/create"><span class="mini-sub-pro">Ajouter des Agent</span></a></li> -->
                               <!--  <li><a title="Edit Students" href="edit-student.html"><span class="mini-sub-pro">Edit Student</span></a></li>
                                <li><a title="Students Profile" href="student-profile.html"><span class="mini-sub-pro">Student Profile</span></a></li> -->
                            <!--  </ul>-->
                        </li>
                        
                         <li>
                           <a class="has-arrow" href="/user_action_dg" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Actions</span></a>
                            <ul class="submenu-angle" aria-expanded="false"> 
                            <li><a title="All Students" href="/user_action_dg"><span class="mini-sub-pro">Mes Actions</span></a></li>
                             <li><a title="All Students" href="/user_actionA_dg"><span class="mini-sub-pro">Actions de ma Direction</span></a></li>
                               <!--  <li><a title="All Students" href="/agents"><span class="mini-sub-pro">Tous les Agents</span></a></li>
                                <li><a title="Add Students" href="/agents/create"><span class="mini-sub-pro">Ajouter des Agent</span></a></li> -->
                               <!--  <li><a title="Edit Students" href="edit-student.html"><span class="mini-sub-pro">Edit Student</span></a></li>
                                <li><a title="Students Profile" href="student-profile.html"><span class="mini-sub-pro">Student Profile</span></a></li> -->
                             </ul>
                        </li>
                        
                         <li>
                             <!--<a class="has-arrow" href="/user_actionA_dg" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Actions de ma Direction</span></a>
                            <ul class="submenu-angle" aria-expanded="false">-->
                            <!--<li><a title="All Students" href="/user_actionA_dg"><span class="mini-sub-pro">Actions</span></a></li>-->
                               <!--  <li><a title="All Students" href="/agents"><span class="mini-sub-pro">Tous les Agents</span></a></li>
                                <li><a title="Add Students" href="/agents/create"><span class="mini-sub-pro">Ajouter des Agent</span></a></li> -->
                               <!--  <li><a title="Edit Students" href="edit-student.html"><span class="mini-sub-pro">Edit Student</span></a></li>
                                <li><a title="Students Profile" href="student-profile.html"><span class="mini-sub-pro">Student Profile</span></a></li> -->
                             <!--</ul>-->
                        </li>
                      <!--   <li>  
                            <a title="Landing Page" href="events.html" aria-expanded="false"><span class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Event</span></a>
                        </li> -->
                        <li>
                            <!-- <a class="has-arrow" href="/actions" aria-expanded="false"><span class="educate-icon educate-professor icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle" aria-expanded="false"> -->
                               <!--  <li><a title="All Professors" href="/actions"><span class="mini-sub-pro">Tous les Actions</span></a></li>
                                <li><a title="Add Professor" href="/actions/create"><span class="mini-sub-pro">Ajouter des Action</span></a></li> -->
                                <!-- <li><a title="Edit Professor" href="edit-professor.html"><span class="mini-sub-pro">Edit Professor</span></a></li>
                                <li><a title="Professor Profile" href="professor-profile.html"><span class="mini-sub-pro">Professor Profile</span></a></li> -->
                           <!--  </ul> -->
                        </li>
                        <li>
                            <!-- <a class="has-arrow" href="/agents" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle" aria-expanded="false"> -->
                               <!--  <li><a title="All Students" href="/agents"><span class="mini-sub-pro">Tous les Agents</span></a></li>
                                <li><a title="Add Students" href="/agents/create"><span class="mini-sub-pro">Ajouter des Agent</span></a></li> -->
                               <!--  <li><a title="Edit Students" href="edit-student.html"><span class="mini-sub-pro">Edit Student</span></a></li>
                                <li><a title="Students Profile" href="student-profile.html"><span class="mini-sub-pro">Student Profile</span></a></li> -->
                            <!-- </ul> -->
                        </li>
                        <li>
                            <!-- <a class="has-arrow" href="/reunions" aria-expanded="false"><span class="educate-icon educate-course icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle" aria-expanded="false"> -->
                                <!-- <li><a title="All Courses" href="/reunions"><span class="mini-sub-pro">Tous les Réunions</span></a></li>
                                <li><a title="Add Courses" href="/reunions/create"><span class="mini-sub-pro">Ajouter des Réunions</span></a></li> -->
                               <!--  <li><a title="Edit Courses" href="edit-course.html"><span class="mini-sub-pro">Edit Course</span></a></li>
                                <li><a title="Courses Profile" href="course-info.html"><span class="mini-sub-pro">Courses Info</span></a></li>
                                <li><a title="Product Payment" href="course-payment.html"><span class="mini-sub-pro">Courses Payment</span></a></li> -->
                            <!-- </ul> -->
                        </li>
                        <li>
                            <!-- <a class="has-arrow" href="/suivi_actions" aria-expanded="false"><span class="educate-icon educate-library icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle" aria-expanded="false"> -->
                                <!-- <li><a title="All Library" href="/suivi_actions"><span class="mini-sub-pro">Suivi d'Action</span></a></li>
                                <li><a title="Add Library" href="/suivi_actions/create"><span class="mini-sub-pro">Ajouter Suivi d'Action</span></a></li> -->
<!--                                 <li><a title="Edit Library" href="edit-library-assets.html"><span class="mini-sub-pro">Edit Library Asset</span></a></li>
 -->                           <!--  </ul> -->
                        </li>
                        <li>
                            <!-- <a class="has-arrow" href="/services" aria-expanded="false"><span class="educate-icon educate-department icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle" aria-expanded="false"> -->
                                <!-- <li><a title="Departments List" href="/services"><span class="mini-sub-pro">Tous les Services</span></a></li>
                                <li><a title="Add Departments" href="/services/create"><span class="mini-sub-pro">Ajouter des Services</span></a></li> -->
<!--                                 <li><a title="Edit Departments" href="edit-department.html"><span class="mini-sub-pro">Edit Departments</span></a></li>
 -->                            <!-- </ul> -->
                        </li>
                        <li>
<!--                             <a class="has-arrow" href="/directions" aria-expanded="false"><span class="educate-icon educate-message icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle" aria-expanded="false"> -->
                               <!--  <li><a title="Inbox" href="/directions"><span class="mini-sub-pro">Tous les Directions</span></a></li>
                                <li><a title="View Mail" href="/directions/create"><span class="mini-sub-pro">Ajouter des Directions</span></a></li> -->
<!--                                 <li><a title="Compose Mail" href="mailbox-compose.html"><span class="mini-sub-pro">Compose Mail</span></a></li>
 -->                           <!--  </ul> -->
                        </li>
                        <li>
                            <!-- <a class="has-arrow" href="/decissions" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle interface-mini-nb-dp" aria-expanded="false"> -->
                               <!--  <li><a title="Google Map" href="/decissions"><span class="mini-sub-pro">Tous les Décissions</span></a></li>
                                <li><a title="Data Maps" href="/decissions/create"><span class="mini-sub-pro">Ajouter des Décissions</span></a></li> -->
                               <!--  <li><a title="Pdf Viewer" href="pdf-viewer.html"><span class="mini-sub-pro">Pdf Viewer</span></a></li>
                                <li><a title="X-Editable" href="x-editable.html"><span class="mini-sub-pro">X-Editable</span></a></li>
                                <li><a title="Code Editor" href="code-editor.html"><span class="mini-sub-pro">Code Editor</span></a></li>
                                <li><a title="Tree View" href="tree-view.html"><span class="mini-sub-pro">Tree View</span></a></li>
                                <li><a title="Preloader" href="preloader.html"><span class="mini-sub-pro">Preloader</span></a></li>
                                <li><a title="Images Cropper" href="images-cropper.html"><span class="mini-sub-pro">Images Cropper</span></a></li> -->
                            <!-- </ul> -->
                        </li>
                        <li>
                            <!-- <a class="has-arrow" href="/indicateurs" aria-expanded="false"><span class="educate-icon educate-charts icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle chart-mini-nb-dp" aria-expanded="false"> -->
                                <!-- <li><a title="Bar Charts" href="/indicateurs"><span class="mini-sub-pro">Tous les Indicateurs</span></a></li>
                                <li><a title="Line Charts" href="/indicateurs/create"><span class="mini-sub-pro">Ajouter des Indicateurs</span></a></li> -->
                                <!-- <li><a title="Area Charts" href="area-charts.html"><span class="mini-sub-pro">Area Charts</span></a></li>
                                <li><a title="Rounded Charts" href="rounded-chart.html"><span class="mini-sub-pro">Rounded Charts</span></a></li>
                                <li><a title="C3 Charts" href="c3.html"><span class="mini-sub-pro">C3 Charts</span></a></li>
                                <li><a title="Sparkline Charts" href="sparkline.html"><span class="mini-sub-pro">Sparkline Charts</span></a></li>
                                <li><a title="Peity Charts" href="peity.html"><span class="mini-sub-pro">Peity Charts</span></a></li> -->
                            <!-- </ul> -->
                        </li>
                        <li>
                            <!-- <a class="has-arrow" href="/suivi_indicateurs" aria-expanded="false"><span class="educate-icon educate-data-table icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle" aria-expanded="false"> -->
                               <!--  <li><a title="Peity Charts" href="/suivi_indicateurs"><span class="mini-sub-pro">Suivi Indicateur</span></a></li>
                                <li><a title="Data Table" href="/suivi_indicateurs/create"><span class="mini-sub-pro">Ajouter Suivi Indicateur</span></a></li> -->
                           <!--  </ul> -->
                        </li>
                       <!--  <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-form icon-wrap"></span> <span class="mini-click-non">Module</span></a>
                            <ul class="submenu-angle form-mini-nb-dp" aria-expanded="false">
                                <li><a title="Basic Form Elements" href="basic-form-element.html"><span class="mini-sub-pro">Bc Form Elements</span></a></li>
                                <li><a title="Advance Form Elements" href="advance-form-element.html"><span class="mini-sub-pro">Ad Form Elements</span></a></li>
                                <li><a title="Password Meter" href="password-meter.html"><span class="mini-sub-pro">Password Meter</span></a></li>
                                <li><a title="Multi Upload" href="multi-upload.html"><span class="mini-sub-pro">Multi Upload</span></a></li>
                                <li><a title="Text Editor" href="tinymc.html"><span class="mini-sub-pro">Text Editor</span></a></li>
                                <li><a title="Dual List Box" href="dual-list-box.html"><span class="mini-sub-pro">Dual List Box</span></a></li>
                            </ul>
                        </li> -->
                        <!-- <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Suivi Module</span></a>
                            <ul class="submenu-angle app-mini-nb-dp" aria-expanded="false">
                                <li><a title="Notifications" href="notifications.html"><span class="mini-sub-pro">Notifications</span></a></li>
                                <li><a title="Alerts" href="alerts.html"><span class="mini-sub-pro">Alerts</span></a></li>
                                <li><a title="Modals" href="modals.html"><span class="mini-sub-pro">Modals</span></a></li>
                                <li><a title="Buttons" href="buttons.html"><span class="mini-sub-pro">Buttons</span></a></li>
                                <li><a title="Tabs" href="tabs.html"><span class="mini-sub-pro">Tabs</span></a></li>
                                <li><a title="Accordion" href="accordion.html"><span class="mini-sub-pro">Accordion</span></a></li>
                            </ul>
                        </li> -->
                        <!-- <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Formation</span></a>
                            <ul class="submenu-angle app-mini-nb-dp" aria-expanded="false">
                                <li><a title="Notifications" href="notifications.html"><span class="mini-sub-pro">Notifications</span></a></li>
                                <li><a title="Alerts" href="alerts.html"><span class="mini-sub-pro">Alerts</span></a></li>
                                <li><a title="Modals" href="modals.html"><span class="mini-sub-pro">Modals</span></a></li>
                                <li><a title="Buttons" href="buttons.html"><span class="mini-sub-pro">Buttons</span></a></li>
                                <li><a title="Tabs" href="tabs.html"><span class="mini-sub-pro">Tabs</span></a></li>
                                <li><a title="Accordion" href="accordion.html"><span class="mini-sub-pro">Accordion</span></a></li>
                            </ul>   
                        </li> -->
                        <li id="removable">
                            <!-- <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-pages icon-wrap"></span> <span class="mini-click-non"></span></a>
                            <ul class="submenu-angle page-mini-nb-dp" aria-expanded="false"> -->
                               <!--  <li><a title="Lock" href="/users"><span class="mini-sub-pro">Les Utilisateurs</span></a></li>
                                <li><a title="Register" href="/inscription"><span class="mini-sub-pro">Ajouter des Utilisateurs</span></a></li>
                                <li><a title="Login" href="/connexion"><span class="mini-sub-pro">Login</span></a></li> -->
                                <!-- <li><a title="Password Recovery" href="password-recovery.html"><span class="mini-sub-pro">Password Recovery</span></a></li>
                                <li><a title="404 Page" href="404.html"><span class="mini-sub-pro">404 Page</span></a></li>
                                <li><a title="500 Page" href="500.html"><span class="mini-sub-pro">500 Page</span></a></li> -->
                            <!-- </ul> -->
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>