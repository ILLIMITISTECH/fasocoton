<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="#"><img class="main-logo" src="{{asset('images/illimitis/collobo.jpeg')}}" style="width:150px;" alt="" /></a>
                <strong><a href="#"><img src="{{asset('images/illimitis/collobo.jpeg')}}" style="width:150px;" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a class="arrow" href="/admin/dashboard/user">
								   
								   <a title="Dashboard v.1" href="/admin/dashboard/user">Accueil</a>
								</a>
                             <!--<ul class="submenu-angle" aria-expanded="true">
                                <li><a title="Dashboard v.1" href="/admin/dashboard/user"><span class="mini-sub-pro">Accueil</span></a></li>
                                <li><a title="Dashboard v.2" href="#"><span class="mini-sub-pro">Dashboard v.2</span></a></li>
                                <li><a title="Dashboard v.3" href="#"><span class="mini-sub-pro">Dashboard v.3</span></a></li>
                                <li><a title="Analytics" href="#"><span class="mini-sub-pro">Analytics</span></a></li>
                                <li><a title="Widgets" href="#"><span class="mini-sub-pro">Widgets</span></a></li> 
                            </ul>  -->
                        </li>
                        
                         <li>
                            <a class="arrow" href="/user_reunion" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Reunions</span></a>
                            <!--<ul class="submenu-angle" aria-expanded="false"> 
                            <li><a title="All Students" href="/user_reunion"><span class="mini-sub-pro">Reunions</span></a></li>-->
                               <!--  <li><a title="All Students" href="/agents"><span class="mini-sub-pro">Tous les Agents</span></a></li>
                                <li><a title="Add Students" href="/agents/create"><span class="mini-sub-pro">Ajouter des Agent</span></a></li> -->
                               <!--  <li><a title="Edit Students" href="edit-student.html"><span class="mini-sub-pro">Edit Student</span></a></li>
                                <li><a title="Students Profile" href="student-profile.html"><span class="mini-sub-pro">Student Profile</span></a></li> -->
                             <!--</ul>--->
                        </li>
                        
                         <li>
                           <a class="has-arrow" href="/user_action" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Actions</span></a>
                            <ul class="submenu-angle" aria-expanded="false"> 
                            <li><a title="All Students" href="/user_action"><span class="mini-sub-pro">Mes Actions</span></a></li>
                            <li><a title="All Students" href="/user_actionA"><span class="mini-sub-pro">Actions de ma Direction</span></a></li>
                               <!--  <li><a title="All Students" href="/agents"><span class="mini-sub-pro">Tous les Agents</span></a></li>
                                <li><a title="Add Students" href="/agents/create"><span class="mini-sub-pro">Ajouter des Agent</span></a></li> -->
                               <!--  <li><a title="Edit Students" href="edit-student.html"><span class="mini-sub-pro">Edit Student</span></a></li>
                                <li><a title="Students Profile" href="student-profile.html"><span class="mini-sub-pro">Student Profile</span></a></li> -->
                             </ul>
                        </li>
                        
                         <li>
                             <!--<a class="has-arrow" href="/user_actionA" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Actions de ma Direction</span></a>
                            <ul class="submenu-angle" aria-expanded="false"> 
                            <li><a title="All Students" href="/user_actionA"><span class="mini-sub-pro">Actions</span></a></li>-->
                               <!--  <li><a title="All Students" href="/agents"><span class="mini-sub-pro">Tous les Agents</span></a></li>
                                <li><a title="Add Students" href="/agents/create"><span class="mini-sub-pro">Ajouter des Agent</span></a></li> -->
                               <!--  <li><a title="Edit Students" href="edit-student.html"><span class="mini-sub-pro">Edit Student</span></a></li>
                                <li><a title="Students Profile" href="student-profile.html"><span class="mini-sub-pro">Student Profile</span></a></li> -->
                             <!--</ul>-->
                        </li>
                      <!--   <li>  
                            <a title="Landing Page" href="events.html" aria-expanded="false"><span class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Event</span></a>
                        </li> -->
                      
                    </ul>
                </nav>
            </div>
        </nav>
    </div>