<aside class="navbar navbar-vertical navbar-expand-lg navbar-transparent" style="margin-top : -2%;">
        <div class="container-fluid">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
            <span class="navbar-toggler-icon"></span>
          </button>
          <h1 class="navbar-brand navbar-brand-autodark">
            <a href="{{asset('collov2/assets/images/icon.png')}}">
              <!--<img src="{{asset('collov2/assets/images/icon.png')}}" width="110" height="32" alt="Tableau de Bord" class="navbar-brand-image">-->
            </a>
          </h1>
         
         <div class="collapse navbar-collapse" id="navbar-menu" style ="background-color :#DFE0E2">
            <ul class="navbar-nav pt-lg-3" style ="background-color : #DFE0E2">
                
              <li class="nav-item active">
                <a class="nav-link" href="/ADMIN/DASHBOARD" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >dashboard</i>

                  </span>
                  <span class="nav-link-title" style = "color : black;">
                    Tableau de bord
                  </span>
                </a>
              </li>
              
            
              <li class="nav-item">
                <a class="nav-link" href="/categories" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >check_box</i>

                  </span>
                  <span class="nav-link-title" style = "color : black;">
                    Categories
                  </span>
                </a>
              </li>

               <li class="nav-item">
                <a class="nav-link" href="/formations" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >model_training</i>

                  </span>
                  <span class="nav-link-title" style = "color : black;">
                    Formations
                  </span>
                </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="/sessions" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color :black;" >event</i></span>

                  <span class="nav-link-title" style = "color : black;">
                   Calendrier des sessions
                  </span>
                </a>
              </li>
                <li class="nav-item">
                <a class="nav-link" href="/inscriptions" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >assignment_turned_in</i></span>

                  <span class="nav-link-title" style = "color : black;">
                    Inscriptions
                  </span>
                </a>
              </li>
               <li class="nav-item">
                <a class="nav-link" href="/prospects" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >record_voice_over</i></span>

                  <span class="nav-link-title" style = "color : black;">
                    Prospects
                  </span>
                </a>
              </li>
           
              
              <li class="nav-item">
                <a class="nav-link" href="/clients" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons"style = "color : black;">badge</i> </span>

                  <span class="nav-link-title" style = "color : black;">
                    Clients
                  </span>
                </a>
              </li>
              
            

              <li class="nav-item">
                <a class="nav-link" href="/documents" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >description</i></span>

                  <span class="nav-link-title" style = "color : black;">
                    Documents
                  </span>
                </a>
              </li>

             
              
              <li class="nav-item">
                <a class="nav-link" href="/contacts" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >contact_mail</i></span>

                  <span class="nav-link-title" style = "color : black;">
                    Contacts
                  </span>
                </a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="#" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >add_comment</i></span>

                  <span class="nav-link-title" style = "color : black;">
                    Feedbacks
                  </span>
                </a>
              </li>
                 <li class="nav-item">
                <a class="nav-link" href="/pays" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >public</i></span>

                  <span class="nav-link-title" style = "color : black;">
                    Pays
                  </span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/agents" >
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="material-icons" style = "color : black;" >admin_panel_settings</i></span>

                  <span class="nav-link-title" style = "color : black;">
                    Agents
                  </span>
                </a>
              </li>
              
              
            
            </ul>
          </div>
        </div>
      </aside>
      <style>
          .nav-item{
              
              font-size : 16px;
              
          }
          .nav-link-icon{
              margin-right : 5%;
               font-size : 16px;
          }
      </style>